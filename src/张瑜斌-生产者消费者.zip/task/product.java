package task;

public class product {
	
	int id;
	
	public product(int id) {
		this.id = id;
	}

}

